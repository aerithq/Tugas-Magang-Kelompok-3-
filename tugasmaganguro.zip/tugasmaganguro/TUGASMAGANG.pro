EAGLE AutoRouter Statistics:

Job           : C:/Users/USER/Downloads/tugasmaganguro/TUGASMAGANG.brd

Start at      : 11:11:45 (3 May 2025)
End at        : 11:11:46 (3 May 2025)
Elapsed time  : 00:00:00

Signals       :     6   RoutingGrid: 19.685 mil  Layers: 1
Connections   :     7   predefined:  0 ( 0 Vias )

Router memory :   25344

Passname          :     Route Optimize1 Optimize2 Optimize3 Optimize4

Time per pass     :  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00
Number of Ripups  :         1         0         0         0         0
max. Level        :         1         0         0         0         0
max. Total        :         1         0         0         0         0

Routed            :         7         7         7         7         7
Vias              :         0         0         0         0         0
Resolution        :   100.0 %   100.0 %   100.0 %   100.0 %   100.0 %

Final             : 100.0% finished
